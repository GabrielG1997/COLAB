# Friends > 2024-12-27 2:01pm
https://universe.roboflow.com/gabriel-alves/friends-z2br8

Provided by a Roboflow user
License: CC BY 4.0

